//import React, { Component }from "react";
import { NavLink } from "react-router-dom";
//import { Click } from "./Clientslistitem";
//import { connect } from 'react-redux';
import PropTypes from "prop-types";
import React from "react";
//import ClientProfile from "../ClientProfile/clientprofile";
import ListItem from "./Clientslistitem";
import clients from "../clients.json";

const ClientsList = ({ onSelectClient }) => (
  <div className="ClientsList">
    {clients.map((client, key) => (
      <NavLink to={"/profile/" + key}>
        <ListItem
          key={key}
          client={client}
          onClick={() => onSelectClient(client)}
        />
      </NavLink>
    ))}
  </div>
);

ClientsList.propTypes = {
  onSelectClient: PropTypes.func,
};

export default ClientsList;
