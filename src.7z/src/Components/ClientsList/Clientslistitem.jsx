const ListItem = ({ client, onClick }) => {
  const shortName = (firstName, lastName) =>
    [firstName, lastName]
      .filter(Boolean)
      .map((item) => item[0])
      .join(".");
  return (
    <div className="ClientsMiniProfile" onClick={onClick}>
      <div className="MiniProfile">
        {shortName(client.general.firstName, client.general.lastName)}
      </div>
      <div className="Content">
        <div className="Header">
          <div>Имя: {client.general.firstName}</div>
          <div>Фамилия: {client.general.lastName}</div>
          <span> </span>
          <div>Компания: {client.job.company}</div>
          <div className="job"> Должность: {client.job.title}</div>
          <span> </span>
          <div>
            Адресс: {client.address.country}, {client.address.city},{" "}
            {client.address.street}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ListItem;
