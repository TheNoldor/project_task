
export const onSelectClient = ({ client }) => {
    console.log(client);
  };