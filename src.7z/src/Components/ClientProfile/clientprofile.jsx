

const ClientProfile = () => {
  console.log();
  return(
    <div className = 'ClientProfile'> </div>
  )
};

export default ClientProfile;
