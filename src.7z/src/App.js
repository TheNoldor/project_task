import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { SearchNav } from "./Components/Search/search";
import ClientProfile from "./Components/ClientProfile/clientprofile";
import "./App.css";
import ClientsList from "./Components/ClientsList/clientslist";

const App = (props) => {
  return (
    <Router>
      <div className="App">
        <SearchNav />
        <ClientsList />
        <ClientProfile />
      </div>
    </Router>
  );
};
console.log();

export default App;
